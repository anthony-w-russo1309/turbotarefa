function gerarResposta() {
  const pergunta = document.getElementById("pergunta").value;

  if (!pergunta.trim()) {
    alert("Cole alguma pergunta, meu chapa.");
    return;
  }

  const respostaSimulada = `
🔍 Pergunta:
${pergunta}

✅ Resposta:
[Exemplo de resposta gerada para a pergunta acima. Aqui entraria a resposta de uma IA.]
  `;

  document.getElementById("resposta").innerText = respostaSimulada;
}
